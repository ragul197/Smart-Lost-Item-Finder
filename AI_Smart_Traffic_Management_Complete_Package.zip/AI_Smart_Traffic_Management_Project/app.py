from flask import Flask, render_template, request, jsonify
from pathlib import Path
import cv2, os, uuid, time
from traffic_logic import AdaptiveSignalController, simulate_counts

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
app.config["MAX_CONTENT_LENGTH"] = 150 * 1024 * 1024
Path(app.config["UPLOAD_FOLDER"]).mkdir(exist_ok=True)
controller = AdaptiveSignalController()
LATEST = {"counts": {"North": 0, "East": 0, "South": 0, "West": 0},
          "signal": "North", "green_seconds": 20, "mode": "demo",
          "message": "Demo data is active. Upload a traffic video to run detection."}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/status")
def status():
    return jsonify(LATEST)

@app.route("/api/demo", methods=["POST"])
def demo():
    global LATEST
    counts = simulate_counts()
    decision = controller.choose(counts)
    LATEST = {"counts": counts, **decision, "mode": "demo",
              "message": "Illustrative simulated counts; not a real traffic measurement."}
    return jsonify(LATEST)

@app.route("/api/upload", methods=["POST"])
def upload():
    global LATEST
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify({"error": "Please choose a video file."}), 400
    ext = Path(f.filename).suffix.lower()
    if ext not in {".mp4", ".avi", ".mov", ".mkv"}:
        return jsonify({"error": "Supported formats: MP4, AVI, MOV, MKV."}), 400
    name = f"{uuid.uuid4().hex}{ext}"
    path = Path(app.config["UPLOAD_FOLDER"]) / name
    f.save(path)
    try:
        counts, output_path, total = detect_video(str(path))
        decision = controller.choose(counts)
        LATEST = {"counts": counts, **decision, "mode": "video",
                  "message": f"Processed {total} sampled frames. Counts are approximate detections in the configured image regions."}
        return jsonify({**LATEST, "processed_frames": total})
    except ImportError as e:
        return jsonify({"error": "YOLO dependencies are missing. Run: pip install -r requirements.txt. Details: " + str(e)}), 500
    except Exception as e:
        return jsonify({"error": "Video processing failed: " + str(e)}), 500
    finally:
        try: path.unlink(missing_ok=True)
        except Exception: pass

def detect_video(path):
    try:
        from ultralytics import YOLO
    except ImportError as e:
        raise ImportError(str(e))
    model = YOLO(os.environ.get("YOLO_MODEL", "yolov8n.pt"))
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise ValueError("OpenCV could not open the uploaded video.")
    counts = {"North": 0, "East": 0, "South": 0, "West": 0}
    sampled = 0
    # Simple educational ROI mapping: split frame into four quadrants.
    # For a real intersection, calibrate lane polygons and count unique tracked vehicles.
    frame_index = 0
    while sampled < 80:
        ok, frame = cap.read()
        if not ok: break
        frame_index += 1
        if frame_index % 5 != 0: continue
        sampled += 1
        h, w = frame.shape[:2]
        results = model(frame, verbose=False, conf=0.35)
        for result in results:
            if result.boxes is None: continue
            for box in result.boxes:
                cls_id = int(box.cls[0])
                # COCO classes: car=2, motorcycle=3, bus=5, truck=7
                if cls_id not in {2, 3, 5, 7}: continue
                x1, y1, x2, y2 = map(float, box.xyxy[0])
                cx, cy = (x1+x2)/2, (y1+y2)/2
                # Approximate region mapping, not lane-level traffic engineering.
                if cy < h*0.5 and cx < w*0.5: counts["North"] += 1
                elif cy < h*0.5 and cx >= w*0.5: counts["East"] += 1
                elif cy >= h*0.5 and cx >= w*0.5: counts["South"] += 1
                else: counts["West"] += 1
    cap.release()
    if sampled == 0: raise ValueError("No readable frames were found.")
    return counts, None, sampled

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
