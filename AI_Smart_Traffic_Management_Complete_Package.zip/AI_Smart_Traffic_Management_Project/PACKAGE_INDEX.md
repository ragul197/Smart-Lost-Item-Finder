# Package contents
- `app.py`, `traffic_logic.py`: Flask app and adaptive timing logic
- `templates/index.html`, `static/style.css`: web dashboard
- `requirements.txt`: dependencies
- `README.md`: setup and demo instructions
- `docs/Project_Report.docx`: editable academic report draft
- `docs/Project_Report.md`: full Markdown report source
- `docs/Project_Presentation.pptx`: editable 14-slide presentation
- `docs/Viva_Questions.md`: 30 viva questions with answers and one-minute explanation
- `docs/Research_References.md`: research papers and official documentation
- `docs/Review_Presentation_Outline.md`: review presentation outline

Before submission: personalize cover details, take screenshots of your own run, run tests, fill results tables with actual measurements, and verify your institution's formatting rules.
