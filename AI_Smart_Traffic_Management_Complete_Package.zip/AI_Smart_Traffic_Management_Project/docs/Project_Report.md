# AI-Based Smart Traffic Management System Using Computer Vision and Deep Learning for Adaptive Signal Optimization
## MCA Final-Year Project Report — Editable Draft

**Student Name:** [Enter name]  
**Register Number:** [Enter register number]  
**Department:** Master of Computer Applications  
**Institution:** [Enter institution]  
**Guide:** [Enter guide name]  
**Academic Year:** 2026–2027

## Abstract
Urban intersections experience changing traffic demand throughout the day. Fixed-time signal plans may allocate green time to a road with little demand while vehicles queue on another approach. This project proposes a student-level prototype that combines computer vision with adaptive signal timing. OpenCV reads a recorded traffic video, a pretrained YOLO object detector identifies common vehicle categories, and detections are aggregated into four configured image regions. A transparent rule-based controller uses demand and accumulated waiting cycles to recommend a signal phase and green duration. A Flask web application presents the results in a dashboard and also supports a demo mode using illustrative synthetic counts.

The prototype is intended to demonstrate an end-to-end workflow rather than to control physical traffic infrastructure. The current region mapping is approximate and repeated detections across frames are not unique vehicle counts. Evaluation should compare fixed-time and adaptive policies under identical, repeatable traffic scenarios using average waiting time, queue length, throughput, detector precision/recall, and processing speed. Real deployment would require calibrated lane regions, multi-object tracking, pedestrian and emergency phases, fail-safe engineering, field validation, and approval by traffic authorities.

**Keywords:** Intelligent Transportation Systems, Computer Vision, YOLO, OpenCV, Adaptive Traffic Signal Control, Deep Learning, Flask.

## Chapter 1 — Introduction
### 1.1 Background
Traffic signals coordinate conflicting movements at road intersections. Fixed-time systems use predefined timing plans, while adaptive systems use traffic measurements to revise timings in response to demand. The Federal Highway Administration describes adaptive signal control as a process that collects traffic data, evaluates timing strategies, implements updates, and repeats the process. Reliable detection and appropriate traffic-engineering constraints are essential.

### 1.2 Problem Statement
A fixed green duration may not reflect current traffic demand. This can contribute to avoidable delay and uneven queues. A low-cost academic prototype is needed to demonstrate how video-based vehicle detection can feed a signal-timing decision process and how the resulting recommendation can be monitored.

### 1.3 Aim
To design and implement a computer-vision-based prototype that estimates traffic demand from video and recommends adaptive green-light timing for a simulated four-way intersection.

### 1.4 Objectives
1. Process traffic video using OpenCV.
2. Detect common vehicle classes using a pretrained YOLO model.
3. Aggregate detections by configured image regions.
4. Implement a transparent adaptive timing heuristic with minimum and maximum green limits.
5. Provide a web dashboard for counts, phase recommendation, and green duration.
6. Define an evaluation plan comparing adaptive and fixed-time strategies.

### 1.5 Scope
The prototype supports recorded video upload and synthetic demo counts. It is designed for one illustrative four-way intersection. It does not connect to real traffic controllers, guarantee unique vehicle counts, identify lanes automatically, or claim real-world congestion reduction without experiments.

## Chapter 2 — Literature Review
### 2.1 YOLO Object Detection
YOLO frames object detection as a single-network prediction task that estimates bounding boxes and class probabilities. This makes the family of detectors suitable for real-time-oriented applications, subject to hardware and model-size constraints. The project uses a pretrained Ultralytics model as a practical implementation baseline.

### 2.2 Adaptive Signal Control
Adaptive signal control systems collect traffic data, evaluate strategies, adjust timings, and repeat. Benefits depend on demand patterns, detector quality, baseline signal quality, and deployment context. Therefore, an experiment should not assume improvement; it should measure it.

### 2.3 Reinforcement Learning for Traffic Signals
Research surveys discuss deep reinforcement learning for signal control, including state representation, reward design, simulation platforms, and open deployment challenges. A full reinforcement-learning agent is outside this manageable first implementation; a rule-based controller provides interpretability and easier debugging. SUMO can be added later for microscopic simulation and reproducible comparison.

### 2.4 Research Gap and Project Contribution
Many advanced approaches require traffic simulation, training, calibration, or complex integration. This project focuses on a compact, explainable demonstration pipeline connecting video detection, demand estimation, a constrained timing heuristic, and a dashboard. Its contribution is educational integration, not a claim of a novel detection architecture or state-of-the-art optimization.

## Chapter 3 — Proposed Methodology
### 3.1 Architecture
Traffic video → OpenCV frame sampling → YOLO vehicle detector → region-based detection counts → adaptive controller → Flask API → browser dashboard.

### 3.2 Vehicle Detection
The detector processes sampled frames and filters the COCO classes corresponding to car, motorcycle, bus, and truck. Confidence thresholding reduces low-confidence detections. The prototype currently counts every qualifying detection in each sampled frame. This is a detection-event count, not a unique vehicle count.

### 3.3 Region Aggregation
For demonstration, the frame is split into four quadrants labelled North, East, South, and West. The center point of each detected bounding box determines its region. This is a placeholder. For meaningful experiments, define polygons matching the incoming lanes and exclude irrelevant background areas.

### 3.4 Adaptive Controller
For direction d, the controller computes a priority score:
**Score(d) = DetectedDemand(d) + λ × WaitingCycles(d)**

The direction with the highest score is selected. Its waiting counter is reset and the counters of other directions are incremented. Green duration is computed from the selected direction’s share of total detected demand and clamped between configured minimum and maximum values. This is a simple heuristic; it is not a trained deep-learning model. Yellow and all-red clearance intervals are not fully simulated in this MVP.

### 3.5 System Modules
- Input and validation: video upload and supported extension checks.
- Detection: sampled-frame YOLO inference.
- Demand estimation: region-level aggregation.
- Timing decision: demand and fairness heuristic.
- Dashboard: count tiles, recommended phase, duration, and status message.
- Demo mode: synthetic counts to verify the UI without model downloads.

## Chapter 4 — System Requirements and Design
### 4.1 Hardware
Recommended: modern laptop, 8 GB RAM or more, and adequate free disk space. A GPU is optional; CPU inference may be slow.

### 4.2 Software
Python 3.10/3.11, Flask, OpenCV, Ultralytics, NumPy, web browser, and Windows/macOS/Linux. SUMO is optional for an extension.

### 4.3 Functional Requirements
1. The user can open a dashboard.
2. The user can run a synthetic demo.
3. The user can upload a supported video.
4. The system detects supported vehicle classes.
5. The system reports approximate directional detection counts.
6. The controller returns a recommended phase and bounded green duration.
7. The dashboard displays results and errors.

### 4.4 Non-Functional Requirements
Usability, modularity, reasonable processing performance, error handling, transparent limitations, and safe separation from physical signal hardware.

## Chapter 5 — Implementation
The backend is implemented in `app.py`, controller logic in `traffic_logic.py`, the interface in `templates/index.html`, and styles in `static/style.css`. Flask exposes `/api/demo`, `/api/upload`, and `/api/status`. The uploaded video is stored temporarily and removed after processing. YOLO weights may be downloaded on first use. Demo mode allows interface and controller testing without those weights.

### 5.1 Installation
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
pip install -r requirements.txt
py app.py
```
Open `http://127.0.0.1:5000`.

### 5.2 Test Cases
| Test | Input | Expected result |
|---|---|---|
| TC01 | Open dashboard | Page loads |
| TC02 | Run demo | Four counts and a selected phase appear |
| TC03 | Upload supported video | Video is processed and counts are returned |
| TC04 | Upload unsupported extension | Validation error appears |
| TC05 | Submit without video | User receives a validation message |
| TC06 | All counts zero in controller unit test | Valid phase is selected and duration stays within bounds |

## Chapter 6 — Evaluation Plan and Results
Do not insert invented performance claims. Run the following experiment with repeatable demand patterns and record actual outputs.

| Metric | Meaning | Measurement method |
|---|---|---|
| Detection precision | Correct vehicle detections / all predicted vehicle detections | Manually label a sample of frames |
| Detection recall | Correct vehicle detections / all ground-truth vehicles | Manually label a sample of frames |
| Average waiting time | Mean time vehicles spend waiting | Best measured in SUMO or a controlled annotated video |
| Average queue length | Mean number of queued vehicles per approach | Lane-specific measurement |
| Throughput | Vehicles that pass the stop line during the experiment | Count completed departures |
| Processing speed | Frames processed per second | Sampled frames / processing time |

### 6.1 Baseline Comparison
Use the same demand scenarios, random seeds, duration, and road configuration for both policies. Compare a fixed-time baseline (equal green split) with the adaptive controller. Repeat multiple runs and report mean and variability. For robust signal-system evaluation, SUMO with TraCI is recommended.

### 6.2 Results Table Template
| Scenario | Policy | Average delay (s) | Average queue | Throughput (vehicles) | Notes |
|---|---|---:|---:|---:|---|
| Low balanced demand | Fixed-time | [measure] | [measure] | [measure] | |
| Low balanced demand | Adaptive | [measure] | [measure] | [measure] | |
| Uneven demand | Fixed-time | [measure] | [measure] | [measure] | |
| Uneven demand | Adaptive | [measure] | [measure] | [measure] | |

## Chapter 7 — Limitations, Ethics, and Future Work
Limitations include quadrant-based regions, repeated frame detections, no multi-object tracking, no lane geometry, no pedestrian phase model, no live hardware, and a simple heuristic instead of a learned policy. Camera footage may contain identifiable people or vehicle plates; use permitted footage, minimize retention, restrict access, and blur sensitive details when appropriate. Future work includes lane polygons, ByteTrack, SUMO/TraCI, emergency vehicle prioritization with verified safeguards, pedestrian timing, model benchmarking, and reinforcement learning in simulation.

## Conclusion
The project demonstrates an end-to-end educational architecture linking video-based vehicle detection to an adaptive timing recommendation and web dashboard. Its primary value is the integration of accessible computer-vision and web technologies with a transparent decision rule. Performance claims must be supported by measured experiments, and the prototype must remain separate from real traffic infrastructure unless independently engineered and approved.

## References
[1] J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, “You Only Look Once: Unified, Real-Time Object Detection,” in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 779–788. doi: 10.1109/CVPR.2016.91.

[2] F. Rasheed, K.-L. A. Yau, R. Md. Noor, C. Wu, and Y.-C. Low, “Deep Reinforcement Learning for Traffic Signal Control: A Review,” *IEEE Access*, vol. 8, pp. 208016–208044, 2020, doi: 10.1109/ACCESS.2020.3034141.

[3] Federal Highway Administration, “Traffic Signal Timing Manual: Chapter 9 — Adaptive Traffic Signal Control.” [Online]. Available: https://ops.fhwa.dot.gov/publications/fhwahop08024/chapter9.htm. Accessed: Oct. 14, 2026.

[4] Federal Highway Administration, “Adaptive Signal Control Technology.” [Online]. Available: https://www.fhwa.dot.gov/innovation/everydaycounts/edc-1/asct.cfm. Accessed: Oct. 14, 2026.

[5] Eclipse SUMO, “SUMO Documentation: Traffic Lights.” [Online]. Available: https://eclipse.dev/sumo/docs/Simulation/Traffic_Lights.html. Accessed: Oct. 14, 2026.

[6] Ultralytics, “Predict Mode.” [Online]. Available: https://docs.ultralytics.com/modes/predict. Accessed: Oct. 14, 2026.

[7] P. A. Lopez et al., “Microscopic Traffic Simulation using SUMO,” in *Proc. IEEE Intelligent Transportation Systems Conference (ITSC)*, 2018.

[8] Federal Highway Administration, “Measures of Effectiveness and Validation Guidance for Adaptive Signal Control Technologies,” FHWA-HOP-13-031, 2013. [Online]. Available: https://ops.fhwa.dot.gov/publications/fhwahop13031/chap1.htm.
