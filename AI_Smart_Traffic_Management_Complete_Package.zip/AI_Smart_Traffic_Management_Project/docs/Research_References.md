# Research References and Useful Documentation

1. J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, “You Only Look Once: Unified, Real-Time Object Detection,” *Proceedings of CVPR*, 2016, pp. 779–788. DOI: 10.1109/CVPR.2016.91. https://openaccess.thecvf.com/content_cvpr_2016/html/Redmon_You_Only_Look_CVPR_2016_paper.html

2. F. Rasheed, K.-L. A. Yau, R. Md. Noor, C. Wu, and Y.-C. Low, “Deep Reinforcement Learning for Traffic Signal Control: A Review,” *IEEE Access*, vol. 8, pp. 208016–208044, 2020. DOI: 10.1109/ACCESS.2020.3034141. https://ieeexplore.ieee.org/document/9241006/

3. Federal Highway Administration, “Traffic Signal Timing Manual: Chapter 9 — Adaptive Traffic Signal Control.” https://ops.fhwa.dot.gov/publications/fhwahop08024/chapter9.htm

4. Federal Highway Administration, “Adaptive Signal Control Technology.” https://www.fhwa.dot.gov/innovation/everydaycounts/edc-1/asct.cfm

5. Federal Highway Administration, “Measures of Effectiveness and Validation Guidance for Adaptive Signal Control Technologies,” FHWA-HOP-13-031, 2013. https://ops.fhwa.dot.gov/publications/fhwahop13031/chap1.htm

6. Eclipse SUMO, “SUMO Documentation — Traffic Lights.” https://eclipse.dev/sumo/docs/Simulation/Traffic_Lights.html

7. P. Alvarez Lopez et al., “Microscopic Traffic Simulation using SUMO,” *Proceedings of the IEEE Intelligent Transportation Systems Conference (ITSC)*, 2018.

8. Ultralytics, “Predict Mode.” https://docs.ultralytics.com/modes/predict

9. “A survey on deep reinforcement learning approaches for traffic signal control,” *Engineering Applications of Artificial Intelligence*, vol. 133, Part A, 2024, article 108100. DOI: 10.1016/j.engappai.2024.108100. https://www.sciencedirect.com/science/article/abs/pii/S0952197624002586

10. “Reinforcement Learning for Adaptive Traffic Signal Control: An Overview,” *Transportation Research Procedia*, vol. 96, pp. 148–155, 2026. DOI: 10.1016/j.trpro.2026.03.020. https://www.sciencedirect.com/science/article/pii/S2352146526002371

Note: Verify institutional IEEE formatting requirements and confirm full bibliographic metadata before final submission. Do not claim an article is a “base paper” unless your guide approves the selection.
