# Viva Voce Preparation

## 1. Project basics
**Q1. What is your project?**  
It is an academic prototype that detects vehicles from traffic video using YOLO and OpenCV, estimates directional demand, and recommends green-light timing through an adaptive rule-based controller.

**Q2. What problem does it address?**  
Fixed-time plans do not always match changing traffic demand. The prototype demonstrates using video-derived demand to adjust a simulated signal recommendation.

**Q3. What is computer vision?**  
A field of AI that enables computers to interpret visual data such as images and videos.

**Q4. What is deep learning?**  
A machine-learning approach using multi-layer neural networks to learn patterns from data.

**Q5. What does YOLO stand for?**  
You Only Look Once. It is a family of object detectors that predicts bounding boxes and classes in a forward pass.

**Q6. Why YOLO?**  
It is practical for object detection in images and videos and has accessible pretrained models. Actual speed and accuracy depend on model size, hardware, and scene conditions.

**Q7. What is OpenCV used for?**  
Reading video, extracting frames, and performing image/video processing.

**Q8. What is Flask?**  
A lightweight Python web framework used here to expose backend routes and render the dashboard.

## 2. Algorithm and architecture
**Q9. Explain the workflow.**  
Video upload → OpenCV samples frames → YOLO detects vehicles → detections are assigned to four image regions → controller scores demand and waiting → Flask returns JSON → dashboard displays counts and recommended phase.

**Q10. How is traffic density calculated?**  
In this MVP, detections are counted by bounding-box center in a quadrant. This is only an approximate proxy and not a calibrated lane-level density measurement.

**Q11. How does adaptive timing work?**  
Each direction gets a score equal to detected demand plus a weighted waiting-cycle value. The highest-scoring direction is selected. Green time is based on its share of the total count and clamped to minimum/maximum values.

**Q12. Is the signal optimizer deep learning?**  
No. YOLO is the deep-learning component; the current optimizer is a rule-based heuristic. A reinforcement-learning policy could be a future extension.

**Q13. Why track waiting cycles?**  
To reduce the risk that a low-volume approach is repeatedly ignored when another direction has high demand.

**Q14. What is a bounding box?**  
A rectangle around a detected object, usually represented by corner coordinates.

**Q15. What are precision and recall?**  
Precision is the fraction of predicted detections that are correct. Recall is the fraction of ground-truth objects that the detector finds.

**Q16. What is mAP?**  
Mean Average Precision, an object-detection metric that summarizes precision-recall performance across classes and IoU thresholds.

## 3. Testing and evaluation
**Q17. How will you prove the system works?**  
Use test cases for dashboard loading, demo cycle, valid and invalid video uploads, and controller bounds. For performance, manually annotate frames and compare the adaptive policy with a fixed-time baseline under repeatable scenarios.

**Q18. What metrics should be reported?**  
Detection precision/recall/mAP, average waiting time, queue length, throughput, and processing FPS. Delay and throughput are best measured in a simulator such as SUMO or in a controlled experiment.

**Q19. What is a baseline?**  
A reference method used for comparison, such as a fixed-time signal plan.

**Q20. Why is SUMO useful?**  
SUMO is an open-source microscopic traffic simulator that can model vehicles, roads, and signalized intersections. It supports experiments without controlling public roads.

**Q21. Can the current code count unique vehicles?**  
No. It accumulates detections from sampled frames, so the same vehicle may be counted multiple times. Multi-object tracking and line-crossing logic are needed for unique counts.

## 4. Limitations and safety
**Q22. What are the main limitations?**  
Quadrant-based regions, repeated detections, no lane calibration, no pedestrian phase, no live hardware, and a simple heuristic rather than a learned control policy.

**Q23. Can this be connected to a real traffic light?**  
Not as supplied. Real deployment requires certified controllers, engineered phase plans, pedestrian and clearance timing, fail-safe design, extensive testing, and traffic authority approval.

**Q24. What happens if the camera fails?**  
This prototype does not implement a field-grade fallback. A real system must detect sensor failure and revert safely to an approved fixed-time or local controller plan.

**Q25. What about privacy?**  
Use footage with permission, limit storage, control access, and blur license plates or faces if present and required.

**Q26. What is future scope?**  
Lane polygon calibration, vehicle tracking, speed and queue estimation, SUMO/TraCI experiments, pedestrian and emergency handling, multi-intersection coordination, and reinforcement learning.

## 5. Basic Python / web questions
**Q27. What is an API?**  
A defined interface that allows software components to exchange requests and responses.

**Q28. What is JSON?**  
A lightweight data-interchange format used by the Flask endpoints to return counts and signal recommendations.

**Q29. Why validate file extensions?**  
To reject unsupported input formats and give clearer error messages. Production systems also need stronger content validation and upload security.

**Q30. What is a virtual environment?**  
An isolated Python environment that keeps project dependencies separate from other projects.

## One-minute explanation
“My project is an AI-based smart traffic management prototype. It uses OpenCV to read traffic video and a pretrained YOLO model to detect vehicles such as cars, buses, motorcycles, and trucks. The detections are grouped into four illustrative directions. A rule-based adaptive controller considers demand and waiting cycles to recommend which direction receives the next green phase and how long it should last. A Flask dashboard displays the counts and recommendation. The current version is intended for academic simulation, and its limitations include approximate regions and repeated detections. For rigorous evaluation, I would compare it with a fixed-time baseline using SUMO and measure delay, queue length, throughput, and detection accuracy.”
