# AI-Based Smart Traffic Management System
## Computer Vision and Deep Learning for Adaptive Signal Optimization

A student-level prototype using Python, Flask, OpenCV, Ultralytics YOLO and a rule-based adaptive signal controller. It supports:
- A web dashboard with four-direction counts and signal recommendation.
- Demo mode using simulated counts (works without model weights).
- Uploading a traffic video and sampling frames for YOLO vehicle detection.
- A simple adaptive controller that prioritizes demand and accumulated waiting.

> Safety and scope: this is a simulation/prototype for academic demonstration. It must NOT control real public-road traffic signals. The video ROI mapping is intentionally simple; real deployments need calibrated lane polygons, vehicle tracking, validated phase plans, fail-safe hardware, pedestrian timing and traffic-engineering approval.

## Requirements
- Python 3.10 or 3.11 recommended
- Internet for the first YOLO model-weight download, unless weights are already available
- A laptop with 8 GB RAM recommended; CPU inference may be slow

## Setup on Windows PowerShell
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
pip install -r requirements.txt
py app.py
```
Open http://127.0.0.1:5000

If PowerShell blocks activation, run the app with:
```powershell
.\.venv\Scripts\python.exe app.py
```

## Demonstration
1. Open the dashboard.
2. Click **Run demo cycle** to generate illustrative traffic counts and a signal recommendation.
3. To use computer vision, select a legally obtained MP4/AVI/MOV/MKV traffic video and click **Analyze video**.
4. The first video analysis may download `yolov8n.pt`. Keep the model file local and follow the model provider's license terms.
5. Explain that the current prototype counts detections sampled from video regions. It does not yet count unique vehicles or estimate real lane queues.

## Project architecture
Video -> OpenCV frame sampling -> YOLO vehicle detector -> region-based counts -> adaptive controller -> Flask JSON API -> browser dashboard.

## Important limitations
- Quadrants are a placeholder for configured approach regions; they are not reliable lane detection.
- Repeated detections across frames are accumulated; counts are not unique vehicle counts.
- No live signal hardware integration is included.
- The timing algorithm is a transparent heuristic, not a trained deep-learning/RL policy.
- Always test against a fixed-time baseline using repeatable scenarios before claiming improvements.

## Suggested next improvements
1. Add a region-of-interest editor and lane polygons.
2. Add ByteTrack/DeepSORT tracking to count unique vehicles and estimate speed/queue length.
3. Use SUMO/TraCI for reproducible traffic simulation and fixed-time baseline comparison.
4. Add pedestrian phases, emergency vehicle handling, minimum/maximum green and clearance intervals.
5. Store experiment runs in SQLite and export CSV metrics.
