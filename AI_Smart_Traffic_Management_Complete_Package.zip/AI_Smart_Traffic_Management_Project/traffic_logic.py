"""Educational adaptive signal timing logic; not certified for real road deployment."""
import random

class AdaptiveSignalController:
    def __init__(self, min_green=10, max_green=45, base_green=10, fairness_weight=0.25):
        self.min_green = min_green
        self.max_green = max_green
        self.base_green = base_green
        self.fairness_weight = fairness_weight
        self.waiting = {d: 0 for d in ("North", "East", "South", "West")}

    def choose(self, counts):
        directions = ("North", "East", "South", "West")
        # Increase a direction's priority with demand and accumulated waiting.
        scores = {}
        for d in directions:
            demand = max(0, int(counts.get(d, 0)))
            scores[d] = demand + self.fairness_weight * self.waiting[d]
        selected = max(directions, key=lambda d: (scores[d], -directions.index(d)))
        for d in directions:
            if d == selected:
                self.waiting[d] = 0
            else:
                self.waiting[d] += 1
        total = sum(max(0, int(counts.get(d, 0))) for d in directions)
        share = (max(0, int(counts.get(selected, 0))) / total) if total else 0.25
        green = int(round(self.min_green + share * (self.max_green - self.min_green)))
        green = max(self.min_green, min(self.max_green, green))
        return {"signal": selected, "green_seconds": green,
                "score": round(scores[selected], 2),
                "waiting_cycles": dict(self.waiting),
                "safety_note": "Simulation only: real controllers require engineered phase plans, clearance intervals, pedestrian timing, and approval."}

def simulate_counts():
    # Reproducible enough for a demo; values are illustrative, not field data.
    return {d: random.randint(2, 28) for d in ("North", "East", "South", "West")}
